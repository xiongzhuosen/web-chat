# app.py

from flask import Flask, render_template, redirect, url_for, request, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, send, emit, join_room, leave_room
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from models import mongo, User, Message
from forms import LoginForm, RegisterForm, MessageForm
import os
from werkzeug.utils import secure_filename
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY')
app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER')
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH'))

# 配置 MongoDB 连接 URI
mongo_uri = f"mongodb://{os.getenv('MONGO_USERNAME')}:{os.getenv('MONGO_PASSWORD')}@{os.getenv('MONGO_HOST')}:{os.getenv('MONGO_PORT')}/{os.getenv('MONGO_DBNAME')}"
mongo.init_app(app)

socketio = SocketIO(app, cors_allowed_origins="*")

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

@app.before_first_request
def create_tables():
    # 对于 MongoDB，不需要创建表
    pass

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.find_by_username(form.username.data)
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('用户名或密码错误')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if User.find_by_username(form.username.data):
            flash('用户名已存在')
            return redirect(url_for('register'))
        new_user = User(username=form.username.data)
        new_user.set_password(form.password.data)
        mongo.db.users.insert_one({
            'username': new_user.username,
            'password_hash': new_user.password_hash
        })
        flash('注册成功，请登录')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login')

@app.route('/messages')
@login_required
def get_messages():
    messages = Message.get_all()
    messages_list = []
    for msg in messages:
        messages_list.append({
            'id': msg.id,
            'content': msg.content,
            'sender_id': msg.sender_id,
            'timestamp': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })
    return {'messages': messages_list}

@socketio.on('message')
def handle_message(msg):
    if current_user.is_authenticated:
        message = Message(content=msg, sender_id=current_user.id)
        message.save()
        emit('message', {'id': message.id, 'content': msg, 'sender_id': current_user.id, 'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}, broadcast=True)

@socketio.on('upload')
def handle_upload(file):
    if current_user.is_authenticated:
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        message = Message(content=f'<a href="/uploads/{filename}" target="_blank">文件: {filename}</a>', sender_id=current_user.id)
        message.save()
        emit('message', {'id': message.id, 'content': message.content, 'sender_id': current_user.id, 'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}, broadcast=True)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)