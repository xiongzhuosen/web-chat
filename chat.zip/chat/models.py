# models.py

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
from datetime import datetime

mongo = PyMongo()

class User(UserMixin):
    def __init__(self, username, password_hash):
        self.id = str(ObjectId())
        self.username = username
        self.password_hash = password_hash

    @staticmethod
    def get(user_id):
        user_data = mongo.db.users.find_one({"_id": ObjectId(user_id)})
        if user_data:
            return User(user_data['username'], user_data['password_hash'])
        return None

    @staticmethod
    def find_by_username(username):
        user_data = mongo.db.users.find_one({"username": username})
        if user_data:
            return User(user_data['username'], user_data['password_hash'])
        return None

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Message:
    def __init__(self, content, sender_id, timestamp=None):
        self.id = str(ObjectId())
        self.content = content
        self.sender_id = sender_id
        self.timestamp = timestamp or datetime.utcnow()

    def save(self):
        mongo.db.messages.insert_one({
            'content': self.content,
            'sender_id': self.sender_id,
            'timestamp': self.timestamp
        })

    @staticmethod
    def get_all():
        messages = list(mongo.db.messages.find().sort('timestamp', pymongo.ASCENDING))
        return messages