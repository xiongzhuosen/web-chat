# forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, FileField, TextAreaField
from wtforms.validators import InputRequired, Length, ValidationError
from models import User

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=150)], render_kw={"placeholder": "用户名"})
    password = PasswordField(validators=[InputRequired(), Length(min=4, max=150)], render_kw={"placeholder": "密码"})
    submit = SubmitField("登录")

class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=150)], render_kw={"placeholder": "用户名"})
    password = PasswordField(validators=[InputRequired(), Length(min=4, max=150)], render_kw={"placeholder": "密码"})
    submit = SubmitField("注册")

    def validate_username(self, username):
        existing_user = User.find_by_username(username.data)
        if existing_user:
            raise ValidationError("用户名已存在，请选择其他用户名。")

class MessageForm(FlaskForm):
    message = TextAreaField('消息', validators=[InputRequired(), Length(max=500)])
    file = FileField('上传文件')
    submit = SubmitField('发送')